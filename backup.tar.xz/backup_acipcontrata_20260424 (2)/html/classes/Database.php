<?php
require_once __DIR__ . '/../config.php';

class Database {
    private static $instance = null;

    public static function getConnection() {
        if (!self::$instance) {
            try {
                $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
            } catch (PDOException $e) {
                // Em um projeto real, logamos o erro em arquivo e não mostramos a senha na tela
                die("Erro crítico de conexão. Verifique as credenciais no config.php");
            }
        }
        return self::$instance;
    }
}
