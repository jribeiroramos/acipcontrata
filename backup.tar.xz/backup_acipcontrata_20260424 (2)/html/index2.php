<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/header.php';
?>

<div class="login-wrapper">
    <a href="index.php">
        <img src="assets/img/logo.jpeg" alt="ACIP Palestina" class="logo-login">
    </a>

    <div class="card-landing">
        <h2 class="h4 mb-4 text-center fw-bold" style="color: #0f172a;">Acesso ao Painel</h2>

        <?php if(isset($_GET['troca']) && $_GET['troca'] == 'sucesso'): ?>
            <div class="alert alert-success border-0 small text-center mb-4" style="border-radius: 12px; background-color: #dcfce7; color: #166534;">
                ✅ <strong>Senha atualizada!</strong><br>
                Faça login agora com sua nova senha definitiva.
            </div>
        <?php endif; ?>

        <?php if(isset($_GET['erro'])): ?>
            <div class="alert alert-danger mb-4 py-2 text-center small border-0" style="background: #fee2e2; color: #dc2626; border-radius: 10px;">
                Usuário ou senha inválidos.
            </div>
        <?php endif; ?>

        <form action="processa_login.php" method="POST">
            <div class="mb-3">
                <label>Login de Usuário</label>
                <input type="text" name="user" class="form-control form-control-lg" required placeholder="Seu usuário">
            </div>

            <div class="mb-4">
                <div class="d-flex justify-content-between">
                    <label>Sua Senha</label>
                    <a href="esqueci_senha.php" class="text-decoration-none fw-bold" style="color: var(--acip-green); font-size: 0.8rem;">Esqueceu a senha?</a>
                </div>
                <input type="password" name="pass" class="form-control form-control-lg" required placeholder="••••••••">
            </div>

            <button type="submit" name="login_btn" class="btn btn-acip shadow-sm">
                ENTRAR NO SISTEMA
            </button>
        </form>

        <div class="mt-4 pt-3 border-top text-center">
            <p class="small text-muted mb-1">Ainda não tem cadastro?</p>
            <a href="cadastro.php" class="fw-bold text-decoration-none" style="color: var(--acip-green);">Crie seu currículo aqui</a>
        </div>
    </div>

</div>

<?php require_once 'includes/footer.php'; ?>
