<?php
require_once 'classes/Database.php';
$db = Database::getConnection();

$user = 'acip';
$pass = '123456';

$stmt = $db->prepare("SELECT id, login, senha, role FROM usuarios WHERE login = ?");
$stmt->execute([$user]);
$u = $stmt->fetch(PDO::FETCH_ASSOC);

echo "<h3>Diagnóstico de Login</h3>";

if (!$u) {
    echo "❌ Erro: Usuário '$user' não encontrado no banco de dados.";
} else {
    echo "✅ Usuário encontrado.<br>";
    echo "Role: " . $u['role'] . "<br>";
    echo "Tamanho do Hash: " . strlen($u['senha']) . " caracteres (Deve ser 60).<br>";

    if (password_verify($pass, $u['senha'])) {
        echo "✅ Senha CORRETA para '123456'.<br>";
        
        $stmt_cv = $db->prepare("SELECT id FROM curriculos WHERE usuario_id = ?");
        $stmt_cv->execute([$u['id']]);
        if ($stmt_cv->fetch()) {
            echo "✅ Currículo vinculado encontrado. O login deveria funcionar.";
        } else {
            echo "❌ Erro: Não existe currículo para este ID de usuário na tabela 'curriculos'.";
        }
    } else {
        echo "❌ Erro: Senha INCORRETA para o hash gravado.";
    }
}
