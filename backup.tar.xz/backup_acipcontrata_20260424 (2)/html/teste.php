<?php
// Usando o caminho completo da URL para testar se o Apache aceita
header("Location: http://186.227.29.3/curriculo/dashboard.php");
exit;
?>
