-- Criar o banco de dados
CREATE DATABASE IF NOT EXISTS sistema_rh CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_rh;

-- Criar a tabela de cidades (vazia, para receber o brasil.sql depois)
CREATE TABLE IF NOT EXISTS `cidades` (
  `ibge` int(11) NOT NULL PRIMARY KEY,
  `municipio` varchar(100),
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `cod_estado` int(11) DEFAULT NULL,
  `estado` varchar(50),
  `uf` char(2),
  `regiao` varchar(20),
  `capital` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabelas auxiliares
CREATE TABLE estados_civis (id INT PRIMARY KEY AUTO_INCREMENT, descricao VARCHAR(50) NOT NULL);
CREATE TABLE niveis_escolaridade (id INT PRIMARY KEY AUTO_INCREMENT, descricao VARCHAR(50) NOT NULL);
CREATE TABLE cursos (id INT PRIMARY KEY AUTO_INCREMENT, nome VARCHAR(100) NOT NULL, area VARCHAR(50));
CREATE TABLE cargos (id INT PRIMARY KEY AUTO_INCREMENT, nome VARCHAR(100) NOT NULL);

-- Tabela de usuários e aprovação
CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    login VARCHAR(50) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    aprovado TINYINT(1) DEFAULT 0,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de currículos
CREATE TABLE curriculos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT UNIQUE NOT NULL,
    nome_completo VARCHAR(100) NOT NULL,
    data_nascimento DATE NOT NULL,
    sexo ENUM('M', 'F', 'Outro'),
    estado_civil_id INT,
    cnh_numero VARCHAR(20),
    cnh_categoria VARCHAR(5),
    cnh_validade DATE,
    endereco TEXT,
    cidade_ibge INT,
    telefone1 VARCHAR(20) NOT NULL,
    telefone2 VARCHAR(20),
    foto_path VARCHAR(255),
    consentimento_lgpd TINYINT(1) DEFAULT 0,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (estado_civil_id) REFERENCES estados_civis(id),
    FOREIGN KEY (cidade_ibge) REFERENCES cidades(ibge)
);

-- Tabelas de Formação e Experiência
CREATE TABLE formacoes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    curriculo_id INT NOT NULL,
    nivel_id INT NOT NULL,
    curso_id INT,
    instituicao VARCHAR(100) NOT NULL,
    ano_conclusao INT NOT NULL,
    tipo ENUM('ACADEMICA', 'EXTRACURRICULAR') DEFAULT 'ACADEMICA',
    FOREIGN KEY (curriculo_id) REFERENCES curriculos(id) ON DELETE CASCADE,
    FOREIGN KEY (nivel_id) REFERENCES niveis_escolaridade(id),
    FOREIGN KEY (curso_id) REFERENCES cursos(id)
);

CREATE TABLE experiencias (
    id INT PRIMARY KEY AUTO_INCREMENT,
    curriculo_id INT NOT NULL,
    empresa VARCHAR(100) NOT NULL,
    cargo_id INT,
    periodo VARCHAR(50),
    cidade_ibge INT,
    FOREIGN KEY (curriculo_id) REFERENCES curriculos(id) ON DELETE CASCADE,
    FOREIGN KEY (cargo_id) REFERENCES cargos(id),
    FOREIGN KEY (cidade_ibge) REFERENCES cidades(ibge)
);

-- Cargas iniciais
INSERT INTO estados_civis (descricao) VALUES ('Solteiro(a)'), ('Casado(a)'), ('Divorciado(a)'), ('Viúvo(a)'), ('União Estável');
INSERT INTO niveis_escolaridade (descricao) VALUES ('Ensino Médio'), ('Técnico'), ('Graduação'), ('Pós-Graduação'), ('Mestrado'), ('Doutorado');
INSERT INTO usuarios (login, senha, role, aprovado) VALUES ('admin', '$2y$10$8Wk1m7W8Ww8Ww8Ww8Ww8Wuef6q6q6q6q6q6q6q6q6q6q6q6q6q6q6', 'admin', 1);

exit;
