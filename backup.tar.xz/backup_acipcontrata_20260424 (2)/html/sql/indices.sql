USE sistema_rh;

-- 1. OTIMIZAÇÃO DA TABELA DE CIDADES (O SEU CONSOLIDADO)
-- Como os campos são do tipo TEXT no seu arquivo original, definimos um prefixo para o índice.
CREATE INDEX idx_cidades_municipio ON cidades(municipio(100));
CREATE INDEX idx_cidades_uf ON cidades(uf(2));
CREATE INDEX idx_cidades_regiao ON cidades(regiao(20));
CREATE INDEX idx_cidades_uf_municipio ON cidades(uf(2), municipio(100));

-- 2. OTIMIZAÇÃO DA TABELA DE USUÁRIOS
-- Otimiza a fila de aprovação do Admin e o login.
CREATE INDEX idx_usuarios_aprovado ON usuarios(aprovado);
CREATE INDEX idx_usuarios_role ON usuarios(role);

-- 3. OTIMIZAÇÃO DA TABELA DE CURRÍCULOS
-- Otimiza a busca por nome, sexo e filtros de CNH.
CREATE INDEX idx_curriculos_nome ON curriculos(nome_completo);
CREATE INDEX idx_curriculos_sexo ON curriculos(sexo);
CREATE INDEX idx_curriculos_cnh ON curriculos(cnh_categoria);

-- 4. OTIMIZAÇÃO DE FORMAÇÕES E EXPERIÊNCIAS
-- Melhora a velocidade de relatórios por escolaridade e histórico.
CREATE INDEX idx_formacoes_tipo ON formacoes(tipo);
CREATE INDEX idx_formacoes_ano ON formacoes(ano_conclusao);
CREATE INDEX idx_experiencias_empresa ON experiencias(empresa);

-- 5. ÍNDICES DE CHAVES ESTRANGEIRAS (OPCIONAL)
-- O MySQL cria estes automaticamente em tabelas InnoDB para as Foreign Keys, 
-- mas reforçá-los garante performance máxima nos JOINs complexos.
CREATE INDEX idx_fk_curriculo_cidade ON curriculos(cidade_ibge);
CREATE INDEX idx_fk_formacao_nivel ON formacoes(nivel_id);
CREATE INDEX idx_fk_experiencia_cargo ON experiencias(cargo_id);
