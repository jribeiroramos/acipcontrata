<?php
// footer.php - Localizado em /var/www/html/includes/footer.php
?>
    <footer class="py-4 text-center mt-auto">
        <div class="container">
            <p class="mb-1 text-muted small">
                &copy; <?= date('Y') ?> <strong>ACIP - Associação Comercial e Industrial de Palestina</strong>
            </p>
            <p class="text-uppercase fw-bold mb-0" style="font-size: 0.65rem; color: #94a3b8; letter-spacing: 1px;">
                LGPD Compliant
            </p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
