<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGC - ACIP Palestina</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <style>
        :root {
            --acip-green: #008445;
            --acip-yellow: #fff200;
            --text-dark: #1e293b;
            --bg-soft: #f8fafc;
        }

        body {
            background-color: var(--bg-soft);
            color: var(--text-dark);
            font-family: 'Inter', sans-serif;
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Estrutura de centralização total */
        .login-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex-grow: 1;
            padding: 40px 20px;
        }

        /* Card de login limpo e moderno */
        .card-landing {
            background: #ffffff;
            border: none;
            border-radius: 25px;
            padding: 45px;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }

        /* Logotipo posicionado acima do card */
        .logo-login {
            max-height: 90px;
            width: auto;
            margin-bottom: 35px;
        }

        /* Botão Verde ACIP */
        .btn-acip {
            background-color: var(--acip-green);
            color: white;
            padding: 14px;
            font-weight: 700;
            border-radius: 12px;
            border: none;
            width: 100%;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-acip:hover {
            background-color: #006837;
            color: white;
            transform: translateY(-1px);
        }

        /* Link de Voltar discreto no rodapé */
        .link-voltar {
            text-decoration: none;
            color: #64748b;
            font-size: 0.95rem;
            margin-top: 25px;
            transition: 0.2s;
            font-weight: 500;
        }

        .link-voltar:hover {
            color: var(--acip-green);
        }

        /* Estilização dos Inputs */
        label {
            font-weight: 700;
            color: var(--acip-green);
            text-transform: uppercase;
            font-size: 0.75rem;
            margin-bottom: 6px;
            display: block;
        }

        .form-control-lg {
            border: 2px solid #e2e8f0 !important;
            border-radius: 12px;
            padding: 14px;
            font-size: 1rem;
            transition: 0.2s;
        }

        .form-control-lg:focus {
            border-color: var(--acip-green) !important;
            box-shadow: 0 0 0 4px rgba(0, 132, 69, 0.08);
            outline: none;
        }

        /* Classes auxiliares para controle de acesso Admin vs Superadmin */
        .only-superadmin {
            display: <?php echo (isset($_SESSION['usuario_role']) && $_SESSION['usuario_role'] === 'superadmin') ? 'block' : 'none'; ?> !important;
        }
        
        .inline-superadmin {
            display: <?php echo (isset($_SESSION['usuario_role']) && $_SESSION['usuario_role'] === 'superadmin') ? 'inline-block' : 'none'; ?> !important;
        }
    </style>
</head>
<body>
<?php
// Atalhos globais para facilitar o uso nas páginas
$is_super = (isset($_SESSION['usuario_role']) && $_SESSION['usuario_role'] === 'superadmin');
$is_admin = (isset($_SESSION['usuario_role']) && $_SESSION['usuario_role'] === 'admin');
?>
