<?php
// 1. ATIVAÇÃO DE LOGS PARA DEPURAÇÃO
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'includes/header.php';
require_once 'classes/Database.php';

if (!isset($_SESSION['usuario_id'])) { header("Location: login.php"); exit; }

$db = Database::getConnection();
$uid = $_SESSION['usuario_id'];

try {
    // 1. Busca dados do currículo com JOIN para residência atual
    $sql_cv = "SELECT c.*, ci.uf as uf_atual
               FROM curriculos c
               LEFT JOIN cidades ci ON c.cidade_ibge = ci.ibge
               WHERE c.usuario_id = ?";
    $cv = $db->prepare($sql_cv);
    $cv->execute([$uid]);
    $dados = $cv->fetch(PDO::FETCH_ASSOC);

    if (!$dados) { die("Erro: Currículo não encontrado."); }

    $erro_tecnico = $_SESSION['erro_detalhado'] ?? null;

    // 2. Busca tabelas auxiliares
    $ufs = $db->query("SELECT DISTINCT uf FROM cidades ORDER BY uf")->fetchAll();
    $estados_civis = $db->query("SELECT * FROM estados_civis")->fetchAll();
    $niveis_escolaridade = $db->query("SELECT * FROM niveis_escolaridade ORDER BY id ASC")->fetchAll();
    $cursos = $db->query("SELECT id, nome FROM cursos ORDER BY CASE WHEN nome = 'Não se aplica' THEN 0 ELSE 1 END, nome ASC")->fetchAll();
    $todos_cargos = $db->query("SELECT id, nome FROM cargos ORDER BY nome ASC")->fetchAll();

    // 3. Busca Históricos Existentes
    $formacoes_salvas = $db->query("SELECT f.* FROM formacoes f WHERE f.curriculo_id = '{$dados['id']}'")->fetchAll();
    $experiencias_salvas = $db->query("SELECT e.*, ci.uf as uf_nome FROM experiencias e LEFT JOIN cidades ci ON e.cidade_ibge = ci.ibge WHERE e.curriculo_id = '{$dados['id']}'")->fetchAll();
    $conhecimentos_salvos = $db->query("SELECT * FROM conhecimentos WHERE curriculo_id = '{$dados['id']}'")->fetchAll();

} catch (Exception $e) {
    die("<div class='alert alert-danger'><b>Erro Crítico:</b> " . $e->getMessage() . "</div>");
}
?>

<style>
    :root { --acip-green: #008445; --acip-yellow: #fff200; }
    html, body { height: 100%; margin: 0; background-color: #f8fafc; font-family: 'Inter', sans-serif; }
    .page-wrapper { display: flex; flex-direction: column; min-height: 100vh; }
    .content-grow { flex: 1; padding-bottom: 60px; }
    .form-control:focus, .form-select:focus { border-color: var(--acip-yellow) !important; box-shadow: 0 0 0 0.25rem rgba(255, 242, 0, 0.25) !important; background-color: #fffdec !important; }
    .section-title { color: var(--acip-green); font-weight: 800; border-left: 6px solid var(--acip-yellow); padding-left: 15px; margin-bottom: 25px; margin-top: 40px; text-transform: uppercase; font-size: 1.1rem; }
    .card { border-radius: 20px; border: none; box-shadow: 0 10px 40px rgba(0,0,0,0.08); background: white; }
    .img-perfil { width: 130px; height: 130px; object-fit: cover; border: 4px solid var(--acip-yellow); border-radius: 20px; }
    .container-verde { background-color: #f0fdf4; border: 1px solid #dcfce7; padding: 25px; border-radius: 20px; margin-bottom: 20px; }
    .bg-historico { background: white; border-radius: 12px; padding: 20px; margin-bottom: 15px; border: 1px solid #e2e8f0; position: relative; }
    .btn-add { background-color: var(--acip-green); color: white; font-weight: bold; border-radius: 10px; border: none; padding: 8px 15px; font-size: 0.85rem; }
    .btn-excluir { color: #dc2626; text-decoration: none; font-size: 0.85rem; font-weight: bold; position: absolute; top: 15px; right: 15px; }
    .footer-minimal { background-color: var(--acip-green); color: white; padding: 30px 0; text-align: center; font-size: 0.85rem; }
    .label-edit { font-size: 0.7rem; font-weight: 800; color: #64748b; text-transform: uppercase; margin-bottom: 3px; display: block; }
    .validation-msg { font-size: 0.75rem; font-weight: 800; margin-top: 4px; display: block; }
    .available { color: #10b981; }
    .unavailable { color: #ef4444; }
</style>

<div class="page-wrapper">
    <div class="container mt-5 content-grow">
        <div class="mb-4">
            <a href="area_candidato.php" class="text-success text-decoration-none fw-bold"><i class="bi bi-arrow-left-circle-fill me-2"></i> VOLTAR AO PAINEL</a>
        </div>

        <?php if (isset($_GET['sucesso'])): ?>
            <div class="alert alert-success border-0 shadow-sm rounded-4 p-3 mb-4"><i class="bi bi-check-circle-fill me-2"></i> Alterações salvas com sucesso!</div>
        <?php endif; ?>

        <?php if ($erro_tecnico): ?>
            <div class="alert alert-danger border-0 shadow-sm rounded-4 p-4 mb-4">
                <div class="d-flex align-items-center"><i class="bi bi-exclamation-triangle-fill fs-3 me-3"></i><h5 class="fw-bold mb-0">Erro ao processar</h5></div>
                <div class="mt-3 p-3 bg-dark text-white rounded-4 small font-monospace" style="opacity: 0.85;"><b>LOG:</b> <?= htmlspecialchars($erro_tecnico) ?></div>
            </div>
        <?php endif; ?>

        <form action="processa_edicao.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="curriculo_id" value="<?= $dados['id'] ?>">

            <div class="card p-4 p-md-5">
                <h2 class="fw-bold mb-5" style="color: var(--acip-green);">ATUALIZAR MEU CURRÍCULO</h2>

                <div class="row align-items-center mb-5 p-3 rounded-4" style="background: #f8fafc; border: 1px solid #e2e8f0;">
                    <div class="col-md-auto text-center">
                        <?php $foto = (!empty($dados['foto_path']) && file_exists($dados['foto_path'])) ? $dados['foto_path'] : 'foto.png'; ?>
                        <img src="<?= $foto ?>" class="img-perfil mb-2" id="preview-foto">
                    </div>
                    <div class="col-md">
                        <label class="fw-bold mb-1 text-uppercase small text-success">Alterar Foto (Opcional)</label>
                        <input type="file" name="foto" id="foto" accept="image/*" class="form-control">
                    </div>
                </div>

                <h3 class="section-title">Objetivo Profissional</h3>
                <textarea name="objetivo" class="form-control mb-4" rows="3"><?= htmlspecialchars($dados['objetivo'] ?? '') ?></textarea>

                <h3 class="section-title">Dados Pessoais e Contato</h3>
                <div class="row g-3 mb-4">
                    <div class="col-md-6"><label class="small fw-bold">NOME COMPLETO</label><input type="text" name="nome_completo" class="form-control" value="<?= htmlspecialchars($dados['nome_completo']) ?>" required></div>
                    <div class="col-md-3"><label class="small fw-bold">DATA NASCIMENTO</label><input type="date" name="data_nascimento" class="form-control" value="<?= $dados['data_nascimento'] ?>" required></div>
                    <div class="col-md-3"><label class="small fw-bold">SEXO</label>
                        <select name="sexo" class="form-select">
                            <option value="M" <?= $dados['sexo'] == 'M' ? 'selected' : '' ?>>Masculino</option>
                            <option value="F" <?= $dados['sexo'] == 'F' ? 'selected' : '' ?>>Feminino</option>
                            <option value="Outro" <?= $dados['sexo'] == 'Outro' ? 'selected' : '' ?>>Outro</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="small fw-bold">E-MAIL</label>
                        <input type="email" name="email" id="email_input" class="form-control" value="<?= htmlspecialchars($dados['email']) ?>" required>
                        <span id="email_feedback" class="validation-msg"></span>
                    </div>
                    <div class="col-md-4"><label class="small fw-bold">WHATSAPP</label><input type="text" name="telefone1" class="form-control sp_celphones" value="<?= htmlspecialchars($dados['telefone1']) ?>" required></div>
                    <div class="col-md-4"><label class="small fw-bold">TELEFONE 2</label><input type="text" name="telefone2" class="form-control sp_celphones" value="<?= ($dados['telefone2'] == 'Não informado') ? '' : htmlspecialchars($dados['telefone2']) ?>"></div>
                    <div class="col-md-12"><label class="small fw-bold">ENDEREÇO</label><input type="text" name="endereco" class="form-control" value="<?= htmlspecialchars($dados['endereco']) ?>" required></div>
                    <div class="col-md-4">
                        <label class="small fw-bold">UF ATUAL</label>
                        <select id="uf_cv" class="form-select" onchange="carregarCidades(this.value, 'cidade_cv')" required>
                            <option value="">...</option>
                            <?php foreach($ufs as $u): ?>
                                <option value="<?= $u['uf'] ?>" <?= $dados['uf_atual'] == $u['uf'] ? 'selected' : '' ?>><?= $u['uf'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-8">
                        <label class="small fw-bold">CIDADE ATUAL</label>
                        <select id="cidade_cv" name="cidade_ibge" class="form-select" required>
                            <option value="<?= $dados['cidade_ibge'] ?>">Manter Cidade Atual</option>
                        </select>
                    </div>
                </div>

                <h3 class="section-title">Documentação (CNH)</h3>
                <div class="row g-3 mb-4">
                    <div class="col-md-4"><label class="small fw-bold">NÚMERO CNH</label><input type="text" name="cnh_numero" class="form-control" value="<?= htmlspecialchars($dados['cnh_numero'] ?? '') ?>"></div>
                    <div class="col-md-4"><label class="small fw-bold">CATEGORIA</label><input type="text" name="cnh_categoria" class="form-control" maxlength="5" value="<?= htmlspecialchars($dados['cnh_categoria'] ?? '') ?>"></div>
                    <div class="col-md-4"><label class="small fw-bold">VALIDADE</label><input type="date" name="cnh_validade" class="form-control" value="<?= $dados['cnh_validade'] ?>"></div>
                </div>

                <h3 class="section-title">Formação Acadêmica</h3>
                <div class="mb-4">
                    <?php foreach($formacoes_salvas as $f): ?>
                        <div class="bg-historico shadow-sm">
                            <a href="excluir_formacao.php?id=<?= $f['id'] ?>" class="btn-excluir" onclick="return confirm('Remover?')"><i class="bi bi-trash"></i></a>
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="label-edit">Nível</label>
                                    <select name="update_form_nivel[<?= $f['id'] ?>]" class="form-select form-select-sm">
                                        <?php foreach($niveis_escolaridade as $n): ?>
                                            <option value="<?= $n['id'] ?>" <?= $f['nivel_id'] == $n['id'] ? 'selected' : '' ?>><?= $n['descricao'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="label-edit">Curso</label>
                                    <select name="update_form_curso[<?= $f['id'] ?>]" class="form-select form-select-sm">
                                        <?php foreach($cursos as $c): ?>
                                            <option value="<?= $c['id'] ?>" <?= $f['curso_id'] == $c['id'] ? 'selected' : '' ?>><?= $c['nome'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="label-edit">Instituição</label>
                                    <input type="text" name="update_form_instituicao[<?= $f['id'] ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars($f['instituicao'] ?? '') ?>">
                                </div>
                                <div class="col-md-2">
                                    <label class="label-edit">Ano Concl.</label>
                                    <input type="number" name="update_form_ano[<?= $f['id'] ?>]" class="form-control form-control-sm" value="<?= $f['ano_conclusao'] ?>">
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="container-verde">
                    <p class="fw-bold small text-success text-uppercase mb-3"><i class="bi bi-plus-circle me-1"></i> Adicionar Nova Formação</p>
                    <div class="row g-3">
                        <div class="col-md-3"><label class="small fw-bold">NÍVEL</label><select name="nivel_id[]" class="form-select"><option value="">Selecionar...</option><?php foreach($niveis_escolaridade as $n): ?><option value="<?= $n['id'] ?>"><?= $n['descricao'] ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-3"><label class="small fw-bold">CURSO</label><select name="curso_id[]" class="form-select"><?php foreach($cursos as $c): ?><option value="<?= $c['id'] ?>"><?= $c['nome'] ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-4"><label class="small fw-bold">INSTITUIÇÃO</label><input type="text" name="instituicao[]" class="form-control"></div>
                        <div class="col-md-2"><label class="small fw-bold">ANO CONCL.</label><input type="number" name="ano_conclusao[]" class="form-control"></div>
                    </div>
                </div>

                <h3 class="section-title">Conhecimentos</h3>
                <div class="mb-4">
                    <?php foreach($conhecimentos_salvos as $c): ?>
                        <div class="bg-historico shadow-sm py-2">
                            <a href="excluir_conhecimento.php?id=<?= $c['id'] ?>" class="btn-excluir"><i class="bi bi-trash"></i></a>
                            <div class="row g-3 align-items-end">
                                <div class="col-md-8">
                                    <label class="label-edit">Descrição</label>
                                    <input type="text" name="update_conh_desc[<?= $c['id'] ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars($c['descricao'] ?? '') ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="label-edit">Nível</label>
                                    <select name="update_conh_nivel[<?= $c['id'] ?>]" class="form-select form-select-sm">
                                        <option value="Básico" <?= $c['nivel'] == 'Básico' ? 'selected' : '' ?>>Básico</option>
                                        <option value="Intermediário" <?= $c['nivel'] == 'Intermediário' ? 'selected' : '' ?>>Intermediário</option>
                                        <option value="Avançado" <?= $c['nivel'] == 'Avançado' ? 'selected' : '' ?>>Avançado</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <button type="button" class="btn btn-success btn-sm fw-bold" onclick="addConhecimento()">+ ADICIONAR NOVO</button>
                </div>
                <div class="container-verde" id="lista-conhecimentos"></div>

                <h3 class="section-title">Experiências Profissionais</h3>
                <div class="mb-4">
                    <?php foreach($experiencias_salvas as $ex): ?>
                        <div class="bg-historico shadow-sm mb-4">
                            <a href="excluir_experiencia.php?id=<?= $ex['id'] ?>" class="btn-excluir" onclick="return confirm('Remover?')"><i class="bi bi-trash"></i></a>
                            <div class="row g-3 mb-2">
                                <div class="col-md-4">
                                    <label class="label-edit">Empresa</label>
                                    <input type="text" name="update_exp_empresa[<?= $ex['id'] ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars($ex['empresa'] ?? '') ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="label-edit">Cargo</label>
                                    <select name="update_exp_cargo[<?= $ex['id'] ?>]" class="form-select form-select-sm">
                                        <?php foreach($todos_cargos as $tc): ?>
                                            <option value="<?= $tc['id'] ?>" <?= $ex['cargo_id'] == $tc['id'] ? 'selected' : '' ?>><?= $tc['nome'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label class="label-edit">Início</label>
                                    <input type="date" name="update_exp_inicio[<?= $ex['id'] ?>]" class="form-control form-control-sm" value="<?= $ex['dt_inicio_experiencia'] ?>">
                                </div>
                                <div class="col-md-2">
                                    <label class="label-edit">Fim</label>
                                    <input type="date" name="update_exp_fim[<?= $ex['id'] ?>]" class="form-control form-control-sm" value="<?= $ex['dt_fim_experiencia'] ?>">
                                </div>
                            </div>
                            <div class="row g-3 mb-2">
                                <div class="col-md-3">
                                    <label class="label-edit">UF</label>
                                    <select class="form-select form-select-sm" onchange="carregarCidades(this.value, 'cidade_update_<?= $ex['id'] ?>')">
                                        <option value="">...</option>
                                        <?php foreach($ufs as $u): ?>
                                            <option value="<?= $u['uf'] ?>" <?= $ex['uf_nome'] == $u['uf'] ? 'selected' : '' ?>><?= $u['uf'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-9">
                                    <label class="label-edit">Cidade</label>
                                    <select name="update_exp_cidade[<?= $ex['id'] ?>]" id="cidade_update_<?= $ex['id'] ?>" class="form-select form-select-sm">
                                        <option value="<?= $ex['cidade_ibge'] ?>">Manter Atual</option>
                                    </select>
                                </div>
                            </div>
                            <label class="label-edit">Atividades</label>
                            <textarea name="update_exp_atividades[<?= $ex['id'] ?>]" class="form-control form-control-sm" rows="2"><?= htmlspecialchars($ex['descricao_atividades'] ?? '') ?></textarea>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="container-verde" id="lista-experiencias">
                    <p class="fw-bold small text-success text-uppercase mb-3"><i class="bi bi-plus-circle me-1"></i> Incluir Nova Experiência Profissional</p>
                    <div class="bloco-exp-novo mb-4">
                        <div class="row g-3 mb-2">
                            <div class="col-md-4"><label class="small fw-bold">EMPRESA</label><input type="text" name="empresa[]" class="form-control"></div>
                            <div class="col-md-4"><label class="small fw-bold">CARGO</label><select name="cargo_id[]" class="form-select"><option value="">Selecionar...</option><?php foreach($todos_cargos as $tc): ?><option value="<?= $tc['id'] ?>"><?= $tc['nome'] ?></option><?php endforeach; ?></select></div>
                            <div class="col-md-2"><label class="small fw-bold">INÍCIO</label><input type="date" name="dt_inicio_experiencia[]" class="form-control"></div>
                            <div class="col-md-2"><label class="small fw-bold">FIM</label><input type="date" name="dt_fim_experiencia[]" class="form-control"></div>
                        </div>
                        <div class="row g-3 mb-2">
                            <div class="col-md-3"><label class="small fw-bold">UF</label><select class="form-select" onchange="carregarCidades(this.value, 'cidade_exp_0')"><option value="">...</option><?php foreach($ufs as $u): ?><option value="<?= $u['uf'] ?>"><?= $u['uf'] ?></option><?php endforeach; ?></select></div>
                            <div class="col-md-9"><label class="small fw-bold">CIDADE</label><select name="exp_cidade_ibge[]" id="cidade_exp_0" class="form-select" disabled><option value="">Selecione o estado</option></select></div>
                        </div>
                        <textarea name="descricao_atividades[]" class="form-control" rows="2" placeholder="Resumo das atividades..."></textarea>
                    </div>
                </div>
                <div class="text-end mb-4"><button type="button" class="btn btn-dark btn-sm fw-bold" onclick="addExperiencia()">+ ADICIONAR OUTRO BLOCO</button></div>

                <div class="text-end mt-5"><button type="submit" class="btn btn-success btn-lg px-5 shadow-lg fw-bold" style="border-radius: 15px;">SALVAR TODAS AS ALTERAÇÕES</button></div>
            </div>
        </form>
    </div>
    <div class="footer-minimal"><div class="container"><span>© 2026 ACIP - Palestina</span></div></div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
let expCount = 1;
$(document).ready(function(){
    var behavior = function (val) { return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009'; };
    $('.sp_celphones').mask(behavior, {onKeyPress: function(val, e, field, options) { field.mask(behavior.apply({}, arguments), options); }});
    
    const ufInicial = $('#uf_cv').val();
    if(ufInicial) carregarCidades(ufInicial, 'cidade_cv', '<?= $dados['cidade_ibge'] ?>');

    // Inicializa cidades das experiências já salvas
    <?php foreach($experiencias_salvas as $ex): ?>
        carregarCidades('<?= $ex['uf_nome'] ?>', 'cidade_update_<?= $ex['id'] ?>', '<?= $ex['cidade_ibge'] ?>');
    <?php endforeach; ?>

    $('#email_input').on('blur', function(){
        const val = $(this).val();
        const currentEmail = "<?= $dados['email'] ?>";
        if(val.includes('@') && val !== currentEmail) {
            $.getJSON('check_availability.php', {type: 'email', value: val}, function(data){
                if(data.exists) { $('#email_feedback').html('<i class="bi bi-x-circle"></i> E-mail em uso!').removeClass('available').addClass('unavailable');
                } else { $('#email_feedback').html('<i class="bi bi-check-circle"></i> Disponível!').removeClass('unavailable').addClass('available'); }
            });
        } else { $('#email_feedback').html(''); }
    });
});

function carregarCidades(uf, targetId, selectedIbge = null) {
    const select = document.getElementById(targetId);
    if (!uf) return;
    select.disabled = false;
    fetch('busca_cidades.php?uf=' + uf).then(r => r.json()).then(data => {
        select.innerHTML = '<option value="">Cidade</option>';
        data.forEach(c => {
            const isSelected = (selectedIbge && c.ibge == selectedIbge) ? 'selected' : '';
            select.innerHTML += `<option value="${c.ibge}" ${isSelected}>${c.municipio}</option>`;
        });
    });
}

function addConhecimento() {
    const html = `<div class="row g-3 mt-2"><div class="col-md-8"><input type="text" name="conhecimento_desc[]" class="form-control" placeholder="Habilidade..."></div><div class="col-md-4"><select name="conhecimento_nivel[]" class="form-select"><option value="Básico">Básico</option><option value="Intermediário">Intermediário</option><option value="Avançado">Avançado</option></select></div></div>`;
    $('#lista-conhecimentos').append(html);
}

function addExperiencia() {
    const html = `
        <div class="bloco-exp-novo mb-4 pt-3 border-top">
            <div class="row g-3 mb-2">
                <div class="col-md-4"><label class="small fw-bold">EMPRESA</label><input type="text" name="empresa[]" class="form-control"></div>
                <div class="col-md-4"><label class="small fw-bold">CARGO</label><select name="cargo_id[]" class="form-select"><option value="">Selecionar...</option><?php foreach($todos_cargos as $tc): ?><option value="<?= $tc['id'] ?>"><?= $tc['nome'] ?></option><?php endforeach; ?></select></div>
                <div class="col-md-2"><label class="small fw-bold">INÍCIO</label><input type="date" name="dt_inicio_experiencia[]" class="form-control"></div>
                <div class="col-md-2"><label class="small fw-bold">FIM</label><input type="date" name="dt_fim_experiencia[]" class="form-control"></div>
            </div>
            <div class="row g-3 mb-2">
                <div class="col-md-3"><label class="small fw-bold">UF</label><select class="form-select" onchange="carregarCidades(this.value, 'cidade_exp_${expCount}')">
                    <option value="">...</option>
                    <?php foreach($ufs as $u): ?><option value="<?= $u['uf'] ?>"><?= $u['uf'] ?></option><?php endforeach; ?>
                </select></div>
                <div class="col-md-9"><label class="small fw-bold">CIDADE</label><select name="exp_cidade_ibge[]" id="cidade_exp_${expCount}" class="form-select" disabled><option value="">Selecione o estado</option></select></div>
            </div>
            <textarea name="descricao_atividades[]" class="form-control" rows="2" placeholder="Descreva as atividades..."></textarea>
        </div>`;
    $('#lista-experiencias').append(html);
    expCount++;
}

document.getElementById('foto').addEventListener('change', function(){
    if(this.files[0]) {
        const reader = new FileReader();
        reader.onload = e => document.getElementById('preview-foto').src = e.target.result;
        reader.readAsDataURL(this.files[0]);
    }
});
</script>
