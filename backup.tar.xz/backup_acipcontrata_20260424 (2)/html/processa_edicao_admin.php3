<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'classes/Database.php';

if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['usuario_role'], ['admin', 'superadmin'])) {
    header("Location: login.php"); exit;
}

$db = Database::getConnection();
$curriculo_id = $_POST['curriculo_id'];

try {
    $db->beginTransaction();

    // 1. Update Dados Básicos
    $sql_cv = "UPDATE curriculos SET nome_completo = ?, email = ?, aprovado = ?, data_nascimento = ?, telefone1 = ?, cidade_ibge = ? WHERE id = ?";
    $db->prepare($sql_cv)->execute([$_POST['nome_completo'], $_POST['email'], $_POST['aprovado'], $_POST['data_nascimento'], $_POST['telefone1'], $_POST['cidade_ibge'], $curriculo_id]);

    // 2. FORMAÇÕES: Update das existentes (IMPORTANTE: nomes batendo com o formulário)
    if (!empty($_POST['update_form_nivel'])) {
        $stmt_up_f = $db->prepare("UPDATE formacoes SET nivel_id = ?, curso_id = ?, instituicao = ?, ano_conclusao = ? WHERE id = ? AND curriculo_id = ?");
        foreach ($_POST['update_form_nivel'] as $fid => $nivel) {
            $stmt_up_f->execute([$nivel, $_POST['update_form_curso'][$fid], $_POST['update_form_instituicao'][$fid], $_POST['update_form_ano'][$fid] ?: null, $fid, $curriculo_id]);
        }
    }

    // 3. FORMAÇÕES: Insert das novas (IMPORTANTE: nomes batendo com o JavaScript)
    if (!empty($_POST['nivel_id'])) {
        $stmt_in_f = $db->prepare("INSERT INTO formacoes (curriculo_id, nivel_id, curso_id, instituicao, ano_conclusao) VALUES (?, ?, ?, ?, ?)");
        foreach ($_POST['nivel_id'] as $k => $nivel) {
            if (!empty($nivel) && !empty($_POST['instituicao'][$k])) {
                $stmt_in_f->execute([$curriculo_id, $nivel, $_POST['curso_id'][$k], $_POST['instituicao'][$k], $_POST['ano_conclusao'][$k] ?: null]);
            }
        }
    }

    // 4. EXPERIÊNCIAS: Update + Insert (Seguindo a mesma lógica)
    if (!empty($_POST['update_exp_empresa'])) {
        $stmt_up_e = $db->prepare("UPDATE experiencias SET empresa = ?, cargo_id = ?, dt_inicio_experiencia = ?, dt_fim_experiencia = ?, descricao_atividades = ? WHERE id = ? AND curriculo_id = ?");
        foreach ($_POST['update_exp_empresa'] as $exid => $empresa) {
            $stmt_up_e->execute([$empresa, $_POST['update_exp_cargo'][$exid], $_POST['update_exp_inicio'][$exid], $_POST['update_exp_fim'][$exid] ?: null, $_POST['update_exp_atividades'][$exid], $exid, $curriculo_id]);
        }
    }
    if (!empty($_POST['empresa'])) {
        $stmt_in_e = $db->prepare("INSERT INTO experiencias (curriculo_id, empresa, cargo_id, dt_inicio_experiencia, dt_fim_experiencia, descricao_atividades) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($_POST['empresa'] as $k => $empresa) {
            if (!empty($empresa)) {
                $stmt_in_e->execute([$curriculo_id, $empresa, $_POST['cargo_id'][$k], $_POST['dt_inicio_experiencia'][$k], $_POST['dt_fim_experiencia'][$k] ?: null, $_POST['descricao_atividades'][$k]]);
            }
        }
    }

    $db->commit();
    header("Location: gestao_candidatos.php?msg=sucesso");
} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) $db->rollBack();
    die("Erro ao salvar: " . $e->getMessage());
}
